from ..abstract import Model as AbstractModel


class Model(AbstractModel):
    """TBATS model, see parent class for details"""
    pass