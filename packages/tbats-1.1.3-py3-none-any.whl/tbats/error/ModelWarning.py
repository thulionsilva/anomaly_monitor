from . import BatsWarning


class ModelWarning(BatsWarning):
    pass
