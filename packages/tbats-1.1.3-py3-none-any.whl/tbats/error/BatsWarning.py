class BatsWarning(UserWarning):
    pass
