class BatsException(Exception):
    pass
