from . import BatsWarning


class InputArgsWarning(BatsWarning):
    pass
