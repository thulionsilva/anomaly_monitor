from sklearn_compat._sklearn_compat import (
    ClassifierTags,  # noqa: F401
    InputTags,  # noqa: F401
    RegressorTags,  # noqa: F401
    Tags,  # noqa: F401
    TargetTags,  # noqa: F401
    TransformerTags,  # noqa: F401
    get_tags,  # noqa: F401
)
