from sklearn_compat._sklearn_compat import (
    _IS_32BIT,  # noqa: F401
    _IS_WASM,  # noqa: F401
    _in_unstable_openblas_configuration,  # noqa: F401
)
