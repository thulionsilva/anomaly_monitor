from sklearn_compat._sklearn_compat import _construct_instances  # noqa: F401
