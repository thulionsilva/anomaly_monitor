from sklearn_compat._sklearn_compat import (
    _fit_context,  # noqa: F401
    is_clusterer,  # noqa: F401
)
