History
-------

Development lead
~~~~~~~~~~~~~~~~

The project started in August 2014 by Fernando Nogueira and focused on SMOTE implementation.
Together with Guillaume Lemaitre, Dayvid Victor, and Christos Aridas, additional under-sampling and over-sampling methods have been implemented as well as major changes in the API to be fully compatible with scikit-learn_.

Contributors
------------

Refers to GitHub contributors page_.

.. _scikit-learn: http://scikit-learn.org
.. _page: https://github.com/scikit-learn-contrib/imbalanced-learn/graphs/contributors
