# -*- coding: utf-8 -*-
"""Tests of skbase pretty printing functionality."""
