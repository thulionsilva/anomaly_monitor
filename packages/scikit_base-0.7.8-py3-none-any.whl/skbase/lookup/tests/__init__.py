# -*- coding: utf-8 -*-
"""Tests of skbase lookup functionality."""
