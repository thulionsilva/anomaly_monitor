# -*- coding: utf-8 -*-
"""Mock package for skbase testing."""
from typing import List

__author__: List[str] = ["fkiraly", "RNKuhns"]
